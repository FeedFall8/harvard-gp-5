#pragma once
#include<string>
#include<vector>
#include"Scene.h"
using namespace std;
const string PATH_TO_STORY = "story.txt";
const string NUMS = "0123456789 \0";
const char SPACE = ' ';
const char FANCYQUOTE = '�';
const char FANCYQUOTE2 = '�';
const char QUOTE = '"';
const char COMMAND = '@';
const char SCENE = 's';
const char PROMPT = 'p';
const char END = '0';
const char NEWLINE = '\n';